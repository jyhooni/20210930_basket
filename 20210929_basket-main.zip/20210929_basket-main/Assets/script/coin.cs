using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class coin : MonoBehaviour
{

    


   // private void OnCollisionEnter2D(Collision2D coll)
    //{
       // if (coll.gameObject.tag == "ball")
        //{
          //  Debug.Log("����!");
            //gameObject�� �ı��ض� ��. ���� �ı��ض� �ȴ�. 
          //  Destroy(gameObject);

           // GameManager.I.addScore(score);

//        }

  //  }
}
